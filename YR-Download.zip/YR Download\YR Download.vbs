' YR Download launcher: starts the engine in the background (if it isn't running yet)
' and opens the app in its own window.
Option Explicit
Dim sh, fso, appDir, i
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appDir = fso.GetParentFolderName(WScript.ScriptFullName)

Function EngineRunning()
    Dim http
    EngineRunning = False
    On Error Resume Next
    ' 127.0.0.1, not "localhost": the engine listens on IPv4 only and "localhost" may resolve to IPv6 first.
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.setTimeouts 2000, 2000, 2000, 2000
    http.open "GET", "http://127.0.0.1:8765/health", False
    http.send
    If Err.Number = 0 Then
        If http.status = 200 Then EngineRunning = True
    End If
    On Error GoTo 0
End Function

If Not EngineRunning() Then
    sh.Run """" & appDir & "\run_forever.bat""", 0, False
    For i = 1 To 40
        WScript.Sleep 500
        If EngineRunning() Then Exit For
    Next
End If

If Not EngineRunning() Then
    MsgBox "YR Download could not start." & vbCrLf & "Run install.bat again, then try once more.", vbExclamation, "YR Download"
    WScript.Quit 1
End If

' Open as an app window (Edge is part of Windows 10/11); fall back to Chrome, then the default browser.
On Error Resume Next
sh.Run "msedge.exe --app=http://localhost:8765/ --window-size=1120,900", 1, False
If Err.Number <> 0 Then
    Err.Clear
    sh.Run "chrome.exe --app=http://localhost:8765/ --window-size=1120,900", 1, False
    If Err.Number <> 0 Then
        Err.Clear
        sh.Run "http://localhost:8765/", 1, False
    End If
End If
