"""Video tab: download from a link, then deliver an editor-friendly 4K MP4 (plain resize or AI upscale)."""
import glob
import os
import re
import subprocess
import sys
import time

from tools import (EDITOR_AUDIO, FFMPEG, GPU_DECODABLE, MODELS_DIR, MP4_FLAGS, NO_WINDOW, OUTPUTS, ROOT, Cancelled,
                   decode_args, editor_video_args, fit_4k, fps_value, has_nvenc, probe, progress_parser, run,
                   tonemap_filter)

# Compact Real-ESRGAN video models (realesr-general-x4v3 / realesr-animevideov3) exported to ONNX.
VIDEO_MODELS = {"real": "upscale_photo.onnx", "anime": "upscale_anime.onnx"}


# YouTube needs a JavaScript runtime for extraction; use the bundled Deno when it's there.
_deno = os.path.join(ROOT, "deno", "deno.exe")
JS_RUNTIME = ["--js-runtimes", "deno:" + _deno] if os.path.isfile(_deno) else []


def friendly_download_error(err):
    """Turn yt-dlp's long error output into one clear sentence for the common cases."""
    if "not a bot" in err or "Sign in to confirm" in err:
        return ("YouTube is temporarily blocking downloads from your internet connection (too many downloads in a "
                "short time). This is not a problem with the app. It usually clears by itself within a few hours "
                "to a day. Meanwhile, links from other sites still work.")
    if "Video unavailable" in err or "This video is unavailable" in err:
        return "This video is unavailable. Check that the link is correct and the video is public."
    if "Private video" in err or "members-only" in err:
        return "This video is private or members-only, so it can't be downloaded."
    if "Unsupported URL" in err:
        return "This link isn't supported. Paste a direct link to a video page."
    lines = [l for l in err.splitlines() if l.startswith("ERROR")]
    return lines[-1] if lines else err


def download(job, url, workdir):
    def on_line(line):
        if line.startswith("TITLE:"):
            job["title"] = line[6:].strip()
        m = re.search(r"\[download\]\s+([\d.]+)%", line)
        if m:
            job["progress"] = float(m.group(1))

    # Up to 4K, prefer SDR (no slow HDR conversion) and codecs the GPU decodes (VP9/H.264 over AV1).
    try:
        run(job, [sys.executable, "-m", "yt_dlp", "-f", "bv*+ba/b", "-S", "res:2160,hdr:sdr,+vcodec",
                  "--no-playlist", "--newline", "--progress", "--no-simulate", *JS_RUNTIME,
                  "--print", "before_dl:TITLE:%(title)s", "--encoding", "utf-8",
                  "--ffmpeg-location", os.path.dirname(FFMPEG), "--merge-output-format", "mkv",
                  "-o", os.path.join(workdir, "src.%(ext)s"), url], on_line)
    except RuntimeError as e:
        raise RuntimeError(friendly_download_error(str(e))) from None
    files = [f for f in glob.glob(os.path.join(workdir, "src.*")) if not f.endswith((".part", ".ytdl"))]
    if not files:
        raise RuntimeError("Download failed")
    return files[0]


def to_4k(job, src, workdir, mode, out):
    info = probe(src)
    w, h, fps = info["w"], info["h"], info["fps"]
    ow, oh = fit_4k(w, h)
    job.update(src_res=f"{w}x{h}", out_res=f"{ow}x{oh}")

    if mode == "fast" or min(w, h) >= 2160:
        job.update(phase="encode", progress=0.0, skipped=["extract", "ai"])
        tail = [*EDITOR_AUDIO, *MP4_FLAGS, "-progress", "pipe:1", "-nostats", out]
        on_line = progress_parser(job, info["duration"])
        if not info["hdr"] and has_nvenc() and info["codec"] in GPU_DECODABLE:
            # Whole pipeline on the GPU: decode -> (resize) -> encode, frames never touch the CPU.
            vf = [] if (w, h) == (ow, oh) else ["-vf", f"scale_cuda={ow}:{oh}:interp_algo=lanczos:format=yuv420p"]
            try:
                run(job, [FFMPEG, "-y", "-hwaccel", "cuda", "-hwaccel_output_format", "cuda", "-i", src,
                          "-map", "0:v:0", "-map", "0:a?", *vf, *editor_video_args(fps, gpu_frames=True), *tail],
                    on_line)
                return
            except Cancelled:
                raise
            except RuntimeError:
                pass  # e.g. 10-bit input the decoder can't keep on the GPU: fall through to the mixed path
        if info["hdr"]:
            vf = tonemap_filter() + f":w={ow}:h={oh}"
        elif (w, h) == (ow, oh):
            vf = "format=yuv420p"
        else:
            vf = f"scale={ow}:{oh}:flags=lanczos,format=yuv420p"
        run(job, [FFMPEG, "-y", *decode_args(info["hdr"]), "-i", src, "-map", "0:v:0", "-map", "0:a?",
                  "-vf", vf, *editor_video_args(fps), *tail], on_line)
        return

    ai_stream(job, src, info, mode, ow, oh, out)


def ai_stream(job, src, info, mode, ow, oh, out):
    """AI upscale with the compact Real-ESRGAN video models on the GPU (DirectML), frames streamed through pipes.

    ~25x faster than running the big image model on every frame, and no temporary PNGs on disk.
    """
    import numpy as np
    import onnxruntime as ort

    sess = ort.InferenceSession(os.path.join(MODELS_DIR, VIDEO_MODELS.get(mode, VIDEO_MODELS["real"])),
                                providers=["DmlExecutionProvider", "CPUExecutionProvider"])
    w, h, fps = info["w"], info["h"], info["fps"]
    # Feed the model at 1/4 of the target size (x4 model -> target); never enlarge the source before the AI.
    iw, ih = min(w, max(2, round(ow / 8) * 2)), min(h, max(2, round(oh / 8) * 2))
    iw, ih = iw // 2 * 2, ih // 2 * 2
    frame_in = iw * ih * 3
    total = max(1, int(info["duration"] * fps_value(fps)))
    job.update(phase="ai", progress=0.0, frames_total=total, frames_done=0, skipped=["extract"])

    pre = ([tonemap_filter()] if info["hdr"] else []) + [f"scale={iw}:{ih}:flags=area"]
    dec = subprocess.Popen([FFMPEG, "-v", "error", *decode_args(info["hdr"]), "-i", src, "-map", "0:v:0",
                            "-vf", ",".join(pre), "-fps_mode", "cfr", "-r", fps, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                           stdout=subprocess.PIPE, creationflags=NO_WINDOW)
    enc = subprocess.Popen([FFMPEG, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{iw * 4}x{ih * 4}",
                            "-r", fps, "-i", "-", "-i", src, "-map", "0:v", "-map", "1:a?",
                            "-vf", f"scale={ow}:{oh}:flags=lanczos,format=yuv420p", *editor_video_args(fps),
                            *EDITOR_AUDIO, "-shortest", *MP4_FLAGS, out],
                           stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=NO_WINDOW)
    job["_procs"] = [dec, enc]
    started, n = time.time(), 0
    try:
        while True:
            if job.get("cancelled"):
                raise Cancelled()
            buf = dec.stdout.read(frame_in)
            if len(buf) < frame_in:
                break
            x = np.frombuffer(buf, np.uint8).reshape(ih, iw, 3).transpose(2, 0, 1)[None].astype(np.float32) / 255.0
            y = sess.run(None, {"input": x})[0][0]
            enc.stdin.write(np.clip(y.transpose(1, 2, 0) * 255.0 + 0.5, 0, 255).astype(np.uint8).tobytes())
            n += 1
            elapsed = time.time() - started
            job.update(frames_done=n, progress=min(99.0, n / total * 100),
                       eta=int(elapsed / n * max(0, total - n)))
        enc.stdin.close()
        err = enc.stderr.read().decode(errors="replace")
        if enc.wait() != 0:
            raise RuntimeError(err[-1500:])
    finally:
        job.pop("_procs", None)
        for p in (dec, enc):
            if p.poll() is None:
                p.kill()
    job.update(phase="encode", progress=100.0, eta=None)


def job_video(job, url, mode, workdir):
    job.update(phase="download", progress=0.0)
    src = download(job, url, workdir)
    out = job["out_path"] = os.path.join(OUTPUTS, job["id"] + ".mp4")
    job["out_name"] = (job.get("title") or "video") + "_4K.mp4"
    to_4k(job, src, workdir, mode, out)
