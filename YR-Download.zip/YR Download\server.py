"""Local media studio: video → 4K, image → 4K, text removal. Serves index.html and runs jobs in threads."""
import json
import os
import re
import shutil
import sys
import threading
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote, unquote

from tools import (ESRGAN, FFMPEG, FFPROBE, ROOT, UPLOADS, WORK, Cancelled, has_nvenc, probe, run,
                   tonemap_filter)

PORT = 8765
# The public website may drive this app on the visitor's own PC (the server still only listens on 127.0.0.1).
# Every other website is refused, so random pages can't start downloads through this app.
WEB_ORIGIN = "https://yairtidhar2015-source.github.io"
IMG_EXT = (".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".avif", ".tif", ".tiff", ".heic")
jobs = {}
uploads = {}


def start_job(target, *args, title=None):
    job_id = uuid.uuid4().hex[:12]
    job = jobs[job_id] = {"id": job_id, "status": "working", "progress": 0.0}
    if title:
        job["title"] = title
    workdir = os.path.join(WORK, job_id)
    os.makedirs(workdir, exist_ok=True)

    def worker():
        try:
            target(job, *args, workdir)
            job.update(status="done", phase="done", progress=100.0, size=os.path.getsize(job["out_path"]))
        except Cancelled:
            job["status"] = "cancelled"
        except Exception as e:
            job.update(status="error", error=str(e))
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    threading.Thread(target=worker, daemon=True).start()
    return job_id


def make_preview(up):
    """Full-resolution PNG used for display and text detection (coordinates match the source)."""
    preview = os.path.join(os.path.dirname(up["path"]), "preview.png")
    if up["kind"] == "image":
        import textremove  # lazy: pulls in OpenCV/ONNX
        img = textremove.read_img(up["path"])
        textremove.write_png(preview, img)
        up["w"], up["h"] = img.shape[1], img.shape[0]
    else:
        info = probe(up["path"])
        up.update(w=info["w"], h=info["h"], duration=info["duration"])
        vf = ["-vf", tonemap_filter()] if info["hdr"] else []
        dummy = {}
        for ss in (["-ss", str(min(1.0, info["duration"] / 2))], []):
            try:
                run(dummy, [FFMPEG, "-y", *(["-init_hw_device", "vulkan"] if vf else []), *ss, "-i", up["path"],
                            "-frames:v", "1", *vf, preview])
                break
            except RuntimeError:
                continue
    up["preview"] = preview


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def origin_allowed(self):
        origin = self.headers.get("Origin")
        return origin in (None, "null", WEB_ORIGIN) or re.fullmatch(r"http://(localhost|127\.0\.0\.1):\d+", origin or "")

    def end_headers(self):
        if self.headers.get("Origin") == WEB_ORIGIN:
            self.send_header("Access-Control-Allow-Origin", WEB_ORIGIN)
            self.send_header("Vary", "Origin")
        super().end_headers()

    def do_OPTIONS(self):
        if self.headers.get("Origin") != WEB_ORIGIN:
            return self.send_json({"error": "forbidden"}, 403)
        self.send_response(204)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Filename")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path, ctype, download_name=None):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(os.path.getsize(path)))
        if download_name:
            self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" + quote(download_name))
        self.end_headers()
        with open(path, "rb") as f:
            shutil.copyfileobj(f, self.wfile, 1024 * 1024)

    def read_json(self):
        return json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")

    def do_GET(self):
        parts = self.path.split("?")[0].strip("/").split("/")
        if parts == [""] or parts == ["index.html"]:
            return self.send_file(os.path.join(ROOT, "index.html"), "text/html; charset=utf-8")
        if parts == ["icon.ico"] or parts == ["favicon.ico"]:
            return self.send_file(os.path.join(ROOT, "icon.ico"), "image/x-icon")
        if parts[0] == "health":
            return self.send_json({"ffmpeg": bool(FFMPEG and FFPROBE), "esrgan": bool(ESRGAN), "gpu": has_nvenc()})
        if parts[0] == "status" and len(parts) == 2 and parts[1] in jobs:
            return self.send_json({k: v for k, v in jobs[parts[1]].items() if not k.startswith("_") and k != "out_path"})
        if parts[0] == "download" and len(parts) == 2 and parts[1] in jobs:
            job = jobs[parts[1]]
            if job["status"] == "done":
                name = re.sub(r'[\\/:*?"<>|]', "_", job["out_name"])
                ctype = "image/png" if name.endswith(".png") else "video/mp4"
                return self.send_file(job["out_path"], ctype, name)
        if parts[0] == "preview" and len(parts) == 2 and parts[1] in uploads:
            return self.send_file(uploads[parts[1]]["preview"], "image/png")
        self.send_json({"error": "not found"}, 404)

    def do_POST(self):
        if not self.origin_allowed():
            return self.send_json({"error": "forbidden"}, 403)
        parts = self.path.strip("/").split("/")
        try:
            if parts[0] == "cancel" and len(parts) == 2 and parts[1] in jobs:
                job = jobs[parts[1]]
                job["cancelled"] = True
                for p in [job.get("_proc"), *job.get("_procs", [])]:
                    if p and p.poll() is None:
                        p.kill()
                return self.send_json({"ok": True})

            if parts[0] == "upload":
                name = unquote(self.headers.get("X-Filename", "file"))
                token = uuid.uuid4().hex[:12]
                folder = os.path.join(UPLOADS, token)
                os.makedirs(folder)
                ext = os.path.splitext(name)[1].lower() or ".bin"
                path = os.path.join(folder, "src" + ext)
                remaining = int(self.headers.get("Content-Length", 0))
                with open(path, "wb") as f:
                    while remaining > 0:
                        chunk = self.rfile.read(min(remaining, 1024 * 1024))
                        if not chunk:
                            break
                        f.write(chunk)
                        remaining -= len(chunk)
                up = uploads[token] = {"path": path, "name": name, "kind": "image" if ext in IMG_EXT else "video"}
                make_preview(up)
                return self.send_json({"token": token, "kind": up["kind"], "w": up["w"], "h": up["h"]})

            if parts[0] == "detect" and len(parts) == 2 and parts[1] in uploads:
                import textremove
                return self.send_json({"boxes": textremove.detect_text(textremove.read_img(uploads[parts[1]]["preview"]))})

            req = self.read_json()
            if parts[0] == "video":
                import video
                url = (req.get("url") or "").strip()
                if not re.match(r"https?://", url):
                    return self.send_json({"error": "Invalid link"}, 400)
                return self.send_json({"id": start_job(video.job_video, url, req.get("mode", "fast"))})

            if parts[0] == "image":
                import images
                url = (req.get("url") or "").strip()
                up = uploads.get(req.get("token") or "")
                if not up and not re.match(r"https?://", url):
                    return self.send_json({"error": "Paste a link or upload a file"}, 400)
                return self.send_json({"id": start_job(images.job_image, url, up and up["path"], req.get("model", "real"),
                                                       title=up and os.path.splitext(up["name"])[0])})

            if parts[0] == "text":
                import textremove
                up = uploads.get(req.get("token") or "")
                if not up:
                    return self.send_json({"error": "Upload a file first"}, 400)
                boxes = [[int(v) for v in b] for b in req.get("boxes", [])]
                return self.send_json({"id": start_job(textremove.job_text, up, boxes, req.get("mode", "fast"))})
        except Exception as e:
            return self.send_json({"error": str(e)}, 500)
        self.send_json({"error": "not found"}, 404)


if __name__ == "__main__":
    url = f"http://localhost:{PORT}"
    print(f"Running at {url}  (keep this window open)")
    print(f"ffmpeg: {FFMPEG}\nReal-ESRGAN: {ESRGAN}")
    if "--no-browser" not in sys.argv:
        threading.Timer(1, lambda: webbrowser.open(url)).start()
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
