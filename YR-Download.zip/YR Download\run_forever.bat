@echo off
rem Keeps the YR Download engine running: restarts it within a few seconds if it ever stops.
cd /d "%~dp0"
mkdir tmp 2>nul
set "TMP=%~dp0tmp"
set "TEMP=%~dp0tmp"
:loop
"%~dp0venv\Scripts\python.exe" server.py --no-browser >> "%~dp0server.log" 2>&1
timeout /t 3 /nobreak >nul
goto loop
