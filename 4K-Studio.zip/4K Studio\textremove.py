"""Text-removal tab: detect text, erase it from images (LaMa inpainting) or videos (delogo / OpenCV inpaint)."""
import os
import subprocess
import threading

import cv2
import numpy as np
import onnxruntime as ort

from tools import (EDITOR_AUDIO, FFMPEG, MODELS_DIR, MP4_FLAGS, NO_WINDOW, OUTPUTS, Cancelled, decode_args,
                   editor_video_args, fps_value, probe, progress_parser, run, tonemap_filter)

LAMA_PATH = os.path.join(MODELS_DIR, "lama_fp32.onnx")
DET_PATH = os.path.join(MODELS_DIR, "text_det.onnx")
_lama = None
_lama_lock = threading.Lock()


def read_img(path):
    img = cv2.imdecode(np.fromfile(path, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise RuntimeError("Could not read the image")
    return img


def write_png(path, img):
    cv2.imencode(".png", img)[1].tofile(path)


def detect_text(img):
    """Return [x, y, w, h] boxes around text found in a BGR image."""
    H, W = img.shape[:2]
    s = min(1.0, 1280 / max(H, W))
    iw, ih = max(32, round(W * s / 32) * 32), max(32, round(H * s / 32) * 32)
    model = cv2.dnn.TextDetectionModel_DB(DET_PATH)
    model.setBinaryThreshold(0.3)
    model.setPolygonThreshold(0.5)
    model.setUnclipRatio(2.0)
    model.setMaxCandidates(300)
    model.setInputParams(1.0 / 255, (iw, ih), (122.67891434, 116.66876762, 104.00698793), True)
    polys, _ = model.detect(img)
    return [list(map(int, cv2.boundingRect(np.array(p, np.int32)))) for p in polys]


def boxes_mask(shape, boxes, pad=4):
    H, W = shape[:2]
    mask = np.zeros((H, W), np.uint8)
    for x, y, w, h in boxes:
        x0, y0 = max(0, int(x) - pad), max(0, int(y) - pad)
        x1, y1 = min(W, int(x + w) + pad), min(H, int(y + h) + pad)
        mask[y0:y1, x0:x1] = 255
    return mask


def _lama_session():
    global _lama
    if _lama is None:
        _lama = ort.InferenceSession(LAMA_PATH, providers=["CPUExecutionProvider"])  # DirectML can't run this model
    return _lama


def inpaint_lama(img, mask, job=None):
    """Fill mask>0 regions with LaMa: one pass per text region (plus surrounding context) squeezed into 512x512.

    One pass per region is seamless and ~10x faster than tiling the region into overlapping windows.
    """
    img = img.copy()
    mask = (mask > 0).astype(np.uint8)
    H, W = img.shape[:2]
    _, _, stats, _ = cv2.connectedComponentsWithStats(cv2.dilate(mask, np.ones((15, 15), np.uint8)))
    sess = _lama_session()
    regions = stats[1:]
    for i, (x, y, w, h, _area) in enumerate(regions):
        if job is not None:
            if job.get("cancelled"):
                raise Cancelled()
            job["progress"] = 10 + 85 * i / max(1, len(regions))
        pad = int(max(min(w, h), 48))
        x0, y0, x1, y1 = max(0, x - pad), max(0, y - pad), min(W, x + w + pad), min(H, y + h + pad)
        crop, m = img[y0:y1, x0:x1], mask[y0:y1, x0:x1]
        x_in = cv2.cvtColor(cv2.resize(crop, (512, 512), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
        m_in = (cv2.resize(m, (512, 512), interpolation=cv2.INTER_NEAREST) > 0).astype(np.float32)
        m_in = cv2.dilate(m_in, np.ones((3, 3), np.uint8))
        with _lama_lock:
            out = sess.run(None, {"image": x_in.transpose(2, 0, 1)[None].astype(np.float32) / 255.0,
                                  "mask": m_in[None, None]})[0][0]
        out = cv2.cvtColor(np.clip(out.transpose(1, 2, 0), 0, 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
        out = cv2.resize(out, (x1 - x0, y1 - y0), interpolation=cv2.INTER_CUBIC)
        crop[m > 0] = out[m > 0]
    return img


def remove_text_image(job, src, boxes, out):
    job.update(phase="ai", progress=5.0)
    img = read_img(src)
    if not boxes:
        raise RuntimeError("No text marked for removal")
    write_png(out, inpaint_lama(img, boxes_mask(img.shape, boxes), job))


def remove_text_video(job, src, boxes, mode, out):
    info = probe(src)
    W, H, fps, duration = info["w"], info["h"], info["fps"], info["duration"]
    if not boxes:
        raise RuntimeError("No text marked for removal")
    job.update(phase="encode", progress=0.0, src_res=f"{W}x{H}", out_res=f"{W}x{H}")
    pre = [tonemap_filter()] if info["hdr"] else []

    if mode == "fast":
        logos = []
        for x, y, w, h in boxes:
            x0, y0 = max(1, int(x) - 4), max(1, int(y) - 4)
            x1, y1 = min(W - 2, int(x + w) + 4), min(H - 2, int(y + h) + 4)
            if x1 - x0 > 2 and y1 - y0 > 2:
                logos.append(f"delogo=x={x0}:y={y0}:w={x1 - x0}:h={y1 - y0}")
        vf = ",".join(pre + logos + ["format=yuv420p"])
        run(job, [FFMPEG, "-y", *decode_args(info["hdr"]), "-i", src, "-map", "0:v:0", "-map", "0:a?", "-vf", vf,
                  *editor_video_args(fps), *EDITOR_AUDIO, *MP4_FLAGS, "-progress", "pipe:1", "-nostats", out],
                 progress_parser(job, duration))
        return

    # "smart": OpenCV inpainting frame by frame, only inside the marked region.
    mask = boxes_mask((H, W), boxes, pad=6)
    ys, xs = np.where(mask > 0)
    m = 16
    rx0, ry0, rx1, ry1 = max(0, xs.min() - m), max(0, ys.min() - m), min(W, xs.max() + m + 1), min(H, ys.max() + m + 1)
    sub_mask = mask[ry0:ry1, rx0:rx1]
    total = max(1, int(duration * fps_value(fps)))
    dec = subprocess.Popen([FFMPEG, "-v", "error", *decode_args(info["hdr"]), "-i", src, "-map", "0:v:0",
                            *(["-vf", pre[0]] if pre else []), "-fps_mode", "cfr", "-r", fps,
                            "-f", "rawvideo", "-pix_fmt", "bgr24", "-"],
                           stdout=subprocess.PIPE, creationflags=NO_WINDOW)
    enc = subprocess.Popen([FFMPEG, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}",
                            "-r", fps, "-i", "-", "-i", src, "-map", "0:v", "-map", "1:a?", "-vf", "format=yuv420p",
                            *editor_video_args(fps), *EDITOR_AUDIO, "-shortest", *MP4_FLAGS, out],
                           stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=NO_WINDOW)
    job["_procs"] = [dec, enc]
    frame_bytes = W * H * 3
    n = 0
    try:
        while True:
            if job.get("cancelled"):
                raise Cancelled()
            buf = dec.stdout.read(frame_bytes)
            if len(buf) < frame_bytes:
                break
            frame = np.frombuffer(buf, np.uint8).reshape(H, W, 3).copy()
            region = frame[ry0:ry1, rx0:rx1]
            frame[ry0:ry1, rx0:rx1] = cv2.inpaint(region, sub_mask, 7, cv2.INPAINT_TELEA)
            enc.stdin.write(frame.tobytes())
            n += 1
            job["progress"] = min(99.0, n / total * 100)
        enc.stdin.close()
        err = enc.stderr.read().decode(errors="replace")
        if enc.wait() != 0:
            raise RuntimeError(err[-1500:])
    finally:
        job.pop("_procs", None)
        for p in (dec, enc):
            if p.poll() is None:
                p.kill()


def job_text(job, upload, boxes, mode, workdir):
    src, kind, name = upload["path"], upload["kind"], upload["name"]
    job["title"] = os.path.splitext(name)[0]
    if kind == "image":
        job["out_path"] = os.path.join(OUTPUTS, job["id"] + ".png")
        job["out_name"] = job["title"] + "_clean.png"
        remove_text_image(job, src, boxes, job["out_path"])
    else:
        job["out_path"] = os.path.join(OUTPUTS, job["id"] + ".mp4")
        job["out_name"] = job["title"] + "_clean.mp4"
        remove_text_video(job, src, boxes, mode, job["out_path"])
