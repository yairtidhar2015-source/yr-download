@echo off
rem 4K Studio installer: run once. Downloads FFmpeg, Real-ESRGAN, the AI models and Python libraries.
cd /d "%~dp0"
title 4K Studio - Install
echo.
echo  ===== 4K Studio installer =====
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo  Python was not found. Installing Python 3.12...
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  echo.
  echo  Python installed. Close this window and run install.bat again.
  pause
  exit /b
)

set "TMP=%~dp0tmp"
set "TEMP=%~dp0tmp"
mkdir tmp models 2>nul

echo  [1/4] Python libraries...
if not exist venv python -m venv venv
venv\Scripts\python.exe -m pip install -q --disable-pip-version-check -U yt-dlp gallery-dl onnxruntime-directml opencv-python-headless numpy
if errorlevel 1 goto fail

echo  [2/4] FFmpeg (video engine, ~170 MB)...
if not exist ffmpeg\bin\ffmpeg.exe (
  powershell -NoProfile -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://github.com/GyanD/codexffmpeg/releases/download/7.1.1/ffmpeg-7.1.1-full_build.zip' -OutFile tmp\ff.zip -UseBasicParsing; Expand-Archive tmp\ff.zip tmp\ffx -Force; Move-Item (Get-ChildItem tmp\ffx -Directory)[0].FullName ffmpeg"
  if errorlevel 1 goto fail
)

echo  [3/4] Real-ESRGAN (AI upscaler, ~45 MB)...
if not exist realesrgan (
  powershell -NoProfile -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip' -OutFile tmp\esr.zip -UseBasicParsing; Expand-Archive tmp\esr.zip realesrgan -Force"
  if errorlevel 1 goto fail
)

echo  [4/4] AI models (~200 MB)...
if not exist models\lama_fp32.onnx (
  powershell -NoProfile -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx' -OutFile models\lama_fp32.onnx -UseBasicParsing"
  if errorlevel 1 goto fail
)
if not exist models\text_det.onnx (
  powershell -NoProfile -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/text_detection_ppocr/text_detection_cn_ppocrv3_2023may.onnx' -OutFile models\text_det.onnx -UseBasicParsing"
  if errorlevel 1 goto fail
)

rmdir /s /q tmp 2>nul
echo.
echo  ===== Done! Double-click start.bat to open 4K Studio. =====
pause
exit /b

:fail
echo.
echo  Something went wrong. Check your internet connection and run install.bat again.
pause
