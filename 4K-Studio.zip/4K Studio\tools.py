"""Shared helpers: tool discovery, subprocess runner, probing and editor-friendly encoding settings."""
import glob
import json
import os
import re
import shutil
import subprocess

ROOT = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(ROOT, "work")
OUTPUTS = os.path.join(ROOT, "outputs")
UPLOADS = os.path.join(ROOT, "uploads")
MODELS_DIR = os.path.join(ROOT, "models")
for _d in (WORK, OUTPUTS, UPLOADS):
    os.makedirs(_d, exist_ok=True)

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
TARGET_W, TARGET_H = 3840, 2160


def find_tool(name):
    local = os.environ.get("LOCALAPPDATA", "")
    candidates = [
        os.path.join(ROOT, "ffmpeg", "bin", name + ".exe"),  # bundled 7.1: NVENC works with the installed driver
        shutil.which(name),
        *glob.glob(os.path.join(local, "Microsoft", "WinGet", "Packages", "Gyan.FFmpeg*", "*", "bin", name + ".exe")),
    ]
    return next((c for c in candidates if c and os.path.isfile(c)), None)


FFMPEG, FFPROBE = find_tool("ffmpeg"), find_tool("ffprobe")
ESRGAN = next(iter(glob.glob(os.path.join(ROOT, "realesrgan", "**", "realesrgan-ncnn-vulkan.exe"), recursive=True)), None)


class Cancelled(Exception):
    pass


def run(job, cmd, on_line=None, cwd=None):
    """Run a subprocess, feeding merged output lines to on_line; honours job cancellation."""
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=cwd, env=env,
                            text=True, encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
    job["_proc"] = proc
    tail = []
    for line in proc.stdout:
        tail = (tail + [line])[-20:]
        if on_line:
            on_line(line)
    proc.wait()
    job.pop("_proc", None)
    if job.get("cancelled"):
        raise Cancelled()
    if proc.returncode != 0:
        raise RuntimeError("".join(tail)[-1500:])


def progress_parser(job, duration, start=0.0, span=100.0):
    """on_line callback that maps ffmpeg `-progress pipe:1` output onto job['progress']."""
    def on_line(line):
        m = re.match(r"out_time_us=(\d+)", line)
        if m and duration:
            job["progress"] = min(99.0, start + int(m.group(1)) / 1e6 / duration * span)
    return on_line


def probe(path):
    out = subprocess.run(
        [FFPROBE, "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=codec_name,width,height,avg_frame_rate,color_transfer:format=duration",
         "-of", "json", path],
        capture_output=True, text=True, check=True, creationflags=NO_WINDOW).stdout
    data = json.loads(out)
    s = data["streams"][0]
    fps = s.get("avg_frame_rate") or "30/1"
    if fps.startswith("0"):
        fps = "30/1"
    try:
        duration = float(data.get("format", {}).get("duration") or 0)
    except ValueError:
        duration = 0.0
    return {"w": int(s["width"]), "h": int(s["height"]), "fps": fps, "duration": duration, "codec": s.get("codec_name"),
            "hdr": s.get("color_transfer") in ("smpte2084", "arib-std-b67")}


def fps_value(fps):
    num, _, den = fps.partition("/")
    return float(num) / float(den or 1)


def fit_4k(w, h):
    """Largest even size fitting 3840x2160 (2160x3840 for portrait), keeping aspect ratio."""
    tw, th = (TARGET_W, TARGET_H) if w >= h else (TARGET_H, TARGET_W)
    scale = min(tw / w, th / h)
    return min(tw, round(w * scale / 2) * 2), min(th, round(h * scale / 2) * 2)


_nvenc = None


def has_nvenc():
    global _nvenc
    if _nvenc is None:
        r = subprocess.run([FFMPEG, "-hide_banner", "-v", "error", "-f", "lavfi", "-i", "color=c=black:s=3840x2160:d=0.2",
                            "-c:v", "h264_nvenc", "-f", "null", "-"], capture_output=True, creationflags=NO_WINDOW)
        _nvenc = r.returncode == 0
    return _nvenc


def decode_args(hdr=False):
    # GPU decode when available (falls back to CPU automatically for codecs the card can't decode).
    if hdr:
        return ["-init_hw_device", "vulkan"]  # libplacebo tone-mapping runs on the GPU via Vulkan
    return ["-hwaccel", "cuda"] if has_nvenc() else []


def tonemap_filter():
    return ("libplacebo=colorspace=bt709:color_primaries=bt709:color_trc=bt709:range=tv:"
            "tonemapping=bt.2390:format=yuv420p")


def editor_video_args(fps, gpu_frames=False):
    """H.264 High, 8-bit 4:2:0, constant frame rate, keyframe every second: opens in any editor.

    gpu_frames: input frames already live on the GPU (CUDA), so no CPU pixel-format conversion is requested.
    """
    gop = str(max(1, round(fps_value(fps))))
    if has_nvenc():
        # p2 ≈ 2x real-time for 4K60 on a GTX 1070 while keeping good quality at cq 21.
        enc = ["-c:v", "h264_nvenc", "-preset", "p2", "-rc", "vbr", "-cq", "21", "-b:v", "0",
               "-maxrate", "25M", "-bufsize", "50M", "-spatial-aq", "1", "-forced-idr", "1"]
    else:
        enc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-maxrate", "25M", "-bufsize", "50M",
               "-sc_threshold", "0"]
    return [*enc, "-profile:v", "high", *([] if gpu_frames else ["-pix_fmt", "yuv420p"]),
            "-g", gop, "-keyint_min", gop, "-fps_mode", "cfr", "-r", fps]


# Codecs a Pascal-era NVIDIA card decodes in hardware (AV1 is not among them).
GPU_DECODABLE = {"h264", "hevc", "vp9", "vp8", "mpeg2video", "mpeg1video", "vc1", "mpeg4"}


EDITOR_AUDIO = ["-c:a", "aac", "-b:a", "192k", "-ar", "48000"]
MP4_FLAGS = ["-movflags", "+faststart"]
