"""Video tab: download from a link, then deliver an editor-friendly 4K MP4 (plain resize or AI upscale)."""
import glob
import math
import os
import re
import subprocess
import sys
import time

from tools import (EDITOR_AUDIO, ESRGAN, FFMPEG, GPU_DECODABLE, MP4_FLAGS, NO_WINDOW, OUTPUTS, Cancelled,
                   decode_args, editor_video_args, fit_4k, has_nvenc, probe, progress_parser, run, tonemap_filter)

MODELS = {"real": "realesrgan-x4plus", "anime": "realesr-animevideov3"}
BATCH = 120  # frames upscaled per batch, keeps disk usage bounded


def download(job, url, workdir):
    def on_line(line):
        if line.startswith("TITLE:"):
            job["title"] = line[6:].strip()
        m = re.search(r"\[download\]\s+([\d.]+)%", line)
        if m:
            job["progress"] = float(m.group(1))

    # Up to 4K, prefer SDR (no slow HDR conversion) and codecs the GPU decodes (VP9/H.264 over AV1).
    run(job, [sys.executable, "-m", "yt_dlp", "-f", "bv*+ba/b", "-S", "res:2160,hdr:sdr,+vcodec",
              "--no-playlist", "--newline", "--progress", "--no-simulate",
              "--print", "before_dl:TITLE:%(title)s", "--encoding", "utf-8",
              "--ffmpeg-location", os.path.dirname(FFMPEG), "--merge-output-format", "mkv",
              "-o", os.path.join(workdir, "src.%(ext)s"), url], on_line)
    files = [f for f in glob.glob(os.path.join(workdir, "src.*")) if not f.endswith((".part", ".ytdl"))]
    if not files:
        raise RuntimeError("Download failed")
    return files[0]


def to_4k(job, src, workdir, mode, out):
    info = probe(src)
    w, h, fps = info["w"], info["h"], info["fps"]
    ow, oh = fit_4k(w, h)
    job.update(src_res=f"{w}x{h}", out_res=f"{ow}x{oh}")

    if mode == "fast" or min(w, h) >= 2160:
        job.update(phase="encode", progress=0.0, skipped=["extract", "ai"])
        tail = [*EDITOR_AUDIO, *MP4_FLAGS, "-progress", "pipe:1", "-nostats", out]
        on_line = progress_parser(job, info["duration"])
        if not info["hdr"] and has_nvenc() and info["codec"] in GPU_DECODABLE:
            # Whole pipeline on the GPU: decode -> (resize) -> encode, frames never touch the CPU.
            vf = [] if (w, h) == (ow, oh) else ["-vf", f"scale_cuda={ow}:{oh}:interp_algo=lanczos:format=yuv420p"]
            try:
                run(job, [FFMPEG, "-y", "-hwaccel", "cuda", "-hwaccel_output_format", "cuda", "-i", src,
                          "-map", "0:v:0", "-map", "0:a?", *vf, *editor_video_args(fps, gpu_frames=True), *tail],
                    on_line)
                return
            except Cancelled:
                raise
            except RuntimeError:
                pass  # e.g. 10-bit input the decoder can't keep on the GPU: fall through to the mixed path
        if info["hdr"]:
            vf = tonemap_filter() + f":w={ow}:h={oh}"
        elif (w, h) == (ow, oh):
            vf = "format=yuv420p"
        else:
            vf = f"scale={ow}:{oh}:flags=lanczos,format=yuv420p"
        run(job, [FFMPEG, "-y", *decode_args(info["hdr"]), "-i", src, "-map", "0:v:0", "-map", "0:a?",
                  "-vf", vf, *editor_video_args(fps), *tail], on_line)
        return

    frames, bin_, bout, segs = (os.path.join(workdir, d) for d in ("frames", "bin", "bout", "segs"))
    for d in (frames, bin_, bout, segs):
        os.makedirs(d, exist_ok=True)

    job.update(phase="extract", progress=0.0)
    run(job, [FFMPEG, "-y", *decode_args(info["hdr"]), "-i", src, "-map", "0:v:0", "-fps_mode", "cfr", "-r", fps,
              *(["-vf", tonemap_filter()] if info["hdr"] else []), os.path.join(frames, "%08d.png")])
    names = sorted(os.listdir(frames))
    total = len(names)
    job.update(phase="ai", frames_total=total, frames_done=0)

    model = MODELS.get(mode, MODELS["real"])
    scale = 4 if mode != "anime" else max(2, min(4, math.ceil(max(oh / h, ow / w))))
    started = time.time()
    for i in range(0, total, BATCH):
        batch = names[i:i + BATCH]
        for n in batch:
            os.replace(os.path.join(frames, n), os.path.join(bin_, n))
        proc = subprocess.Popen([ESRGAN, "-i", bin_, "-o", bout, "-n", model, "-s", str(scale), "-f", "png"],
                                cwd=os.path.dirname(ESRGAN), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                creationflags=NO_WINDOW)
        job["_proc"] = proc
        while proc.poll() is None:
            done = i + len(os.listdir(bout))
            job.update(frames_done=done, progress=done / total * 100)
            if done:
                job["eta"] = int((time.time() - started) / done * (total - done))
            time.sleep(1)
        job.pop("_proc", None)
        if job.get("cancelled"):
            raise Cancelled()
        if proc.returncode != 0:
            raise RuntimeError("Real-ESRGAN failed: " + proc.stderr.read().decode(errors="replace")[-1000:])
        # Encode this batch to a 4K segment, then free the disk space.
        run(job, [FFMPEG, "-y", "-framerate", fps, "-start_number", str(int(batch[0][:8])),
                  "-i", os.path.join(bout, "%08d.png"), "-frames:v", str(len(batch)),
                  "-vf", f"scale={ow}:{oh}:flags=lanczos,format=yuv420p", *editor_video_args(fps),
                  os.path.join(segs, f"{i // BATCH:05d}.mp4")])
        for d in (bin_, bout):
            for n in os.listdir(d):
                os.remove(os.path.join(d, n))

    job.update(phase="encode", progress=100.0, eta=None)
    lst = os.path.join(workdir, "list.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for s in sorted(os.listdir(segs)):
            f.write(f"file '{os.path.join(segs, s)}'\n")
    run(job, [FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", lst, "-i", src, "-map", "0:v", "-map", "1:a?",
              "-c:v", "copy", *EDITOR_AUDIO, "-shortest", *MP4_FLAGS, out])


def job_video(job, url, mode, workdir):
    job.update(phase="download", progress=0.0)
    src = download(job, url, workdir)
    out = job["out_path"] = os.path.join(OUTPUTS, job["id"] + ".mp4")
    job["out_name"] = (job.get("title") or "video") + "_4K.mp4"
    to_4k(job, src, workdir, mode, out)
