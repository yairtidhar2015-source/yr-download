@echo off
cd /d "%~dp0"
set "TMP=%~dp0tmp"
set "TEMP=%~dp0tmp"
"%~dp0venv\Scripts\python.exe" server.py
pause
