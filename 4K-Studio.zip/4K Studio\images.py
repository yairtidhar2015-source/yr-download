"""Image tab: download an image from a link (or use an uploaded one) and upscale it to 4K with Real-ESRGAN."""
import glob
import os
import re
import subprocess
import sys
import urllib.request

from tools import ESRGAN, FFMPEG, NO_WINDOW, OUTPUTS, Cancelled, probe, run

IMG_EXT = (".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".avif", ".tif", ".tiff", ".heic")
MODELS = {"real": "realesrgan-x4plus", "anime": "realesrgan-x4plus-anime"}
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"


def _images_in(folder):
    found = [f for f in glob.glob(os.path.join(folder, "**", "*"), recursive=True) if f.lower().endswith(IMG_EXT)]
    return sorted(found, key=os.path.getsize, reverse=True)


def download_image(job, url, workdir):
    # 1) Direct image link.
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=30) as r:
            ctype = r.headers.get_content_type()
            if ctype.startswith("image/"):
                path = os.path.join(workdir, "src." + ctype.split("/")[1].replace("jpeg", "jpg").split("+")[0])
                with open(path, "wb") as f:
                    f.write(r.read())
                return path
    except Exception:
        pass
    # 2) Gallery sites (Instagram, Pinterest, X, Reddit, ...).
    try:
        run(job, [sys.executable, "-m", "gallery_dl", "--range", "1", "-D", workdir, url])
    except Cancelled:
        raise
    except Exception:
        pass
    found = _images_in(workdir)
    if found:
        return found[0]
    # 3) Video pages (YouTube etc.): take the thumbnail.
    try:
        run(job, [sys.executable, "-m", "yt_dlp", "--skip-download", "--write-thumbnail", "--no-playlist",
                  "--ffmpeg-location", os.path.dirname(FFMPEG), "-o", os.path.join(workdir, "thumb.%(ext)s"), url])
    except Cancelled:
        raise
    except Exception:
        pass
    found = _images_in(workdir)
    if not found:
        raise RuntimeError("No image found at this link")
    return found[0]


def upscale_image(job, src, workdir, model_key, out):
    job.update(phase="ai", progress=10.0)
    png = os.path.join(workdir, "in.png")
    run(job, [FFMPEG, "-y", "-i", src, "-frames:v", "1", png])  # normalise webp/avif/gif/... to PNG
    info = probe(png)
    w, h = info["w"], info["h"]
    long_side = 3840
    scale = long_side / max(w, h)
    job.update(src_res=f"{w}x{h}")
    if scale > 1:
        up = os.path.join(workdir, "up.png")
        proc = subprocess.Popen([ESRGAN, "-i", png, "-o", up, "-n", MODELS.get(model_key, MODELS["real"]), "-s", "4"],
                                cwd=os.path.dirname(ESRGAN), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                creationflags=NO_WINDOW)
        job["_proc"] = proc
        proc.wait()
        job.pop("_proc", None)
        if job.get("cancelled"):
            raise Cancelled()
        if proc.returncode != 0 or not os.path.isfile(up):
            raise RuntimeError("Real-ESRGAN failed: " + proc.stderr.read().decode(errors="replace")[-800:])
        png = up
    ow, oh = max(1, round(w * scale)), max(1, round(h * scale))
    if scale < 1:  # already bigger than 4K: keep original size
        ow, oh = w, h
    job.update(out_res=f"{ow}x{oh}", progress=90.0)
    run(job, [FFMPEG, "-y", "-i", png, "-vf", f"scale={ow}:{oh}:flags=lanczos", "-frames:v", "1", out])


def job_image(job, url, upload_path, model_key, workdir):
    job.update(phase="download", progress=0.0)
    src = upload_path or download_image(job, url, workdir)
    base = os.path.splitext(os.path.basename(src))[0]
    if base in ("src", "thumb") or re.fullmatch(r"[0-9a-f]{12}", base):
        base = "image"
    job.setdefault("title", base)
    job["out_path"] = os.path.join(OUTPUTS, job["id"] + ".png")
    job["out_name"] = job["title"] + "_4K.png"
    upscale_image(job, src, workdir, model_key, job["out_path"])
